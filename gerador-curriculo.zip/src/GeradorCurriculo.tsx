
import React, { useState } from "react";

const GeradorCurriculo = () => {
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [telefone, setTelefone] = useState("");
  const [formacao, setFormacao] = useState("");
  const [experiencias, setExperiencias] = useState("");
  const [skills, setSkills] = useState("");
  const [vaga, setVaga] = useState("");
  const [curriculo, setCurriculo] = useState("");

  const gerarCurriculo = () => {
    const texto = `Currículo Personalizado\n\nNome: ${nome}\nEmail: ${email}\nTelefone: ${telefone}\n\nFormação Acadêmica:\n${formacao}\n\nResumo Profissional:\nProfissional com experiência em ${experiencias}.\n\nHabilidades:\n${skills}\n\nObjetivo:\nAtuar na vaga de ${vaga}, utilizando minhas habilidades e conhecimentos para contribuir com a empresa.`;
    setCurriculo(texto);
  };

  const baixarPDF = () => {
    const blob = new Blob([curriculo], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "curriculo.pdf";
    a.click();
  };

  const copiarTexto = () => {
    navigator.clipboard.writeText(curriculo);
    alert("Currículo copiado para a área de transferência!");
  };

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-4">
      <h1 className="text-3xl font-bold text-center">Gerador de Currículo</h1>
      <div className="space-y-2">
        <input className="w-full p-2 border rounded" placeholder="Seu nome" value={nome} onChange={(e) => setNome(e.target.value)} />
        <input className="w-full p-2 border rounded" placeholder="Seu email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <input className="w-full p-2 border rounded" placeholder="Seu telefone" value={telefone} onChange={(e) => setTelefone(e.target.value)} />
        <textarea className="w-full p-2 border rounded" placeholder="Sua formação acadêmica" value={formacao} onChange={(e) => setFormacao(e.target.value)} />
        <textarea className="w-full p-2 border rounded" placeholder="Suas experiências profissionais" value={experiencias} onChange={(e) => setExperiencias(e.target.value)} />
        <textarea className="w-full p-2 border rounded" placeholder="Suas habilidades (soft/hard skills)" value={skills} onChange={(e) => setSkills(e.target.value)} />
        <textarea className="w-full p-2 border rounded" placeholder="Descrição da vaga ou cargo desejado" value={vaga} onChange={(e) => setVaga(e.target.value)} />
        <button className="bg-blue-600 text-white px-4 py-2 rounded" onClick={gerarCurriculo}>Gerar Currículo</button>
      </div>
      {curriculo && (
        <div className="space-y-4 bg-gray-100 p-4 rounded shadow">
          <pre className="whitespace-pre-wrap text-sm">{curriculo}</pre>
          <div className="flex gap-2">
            <button className="bg-green-600 text-white px-4 py-2 rounded" onClick={baixarPDF}>Baixar PDF</button>
            <button className="bg-gray-600 text-white px-4 py-2 rounded" onClick={copiarTexto}>Copiar Currículo</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default GeradorCurriculo;
