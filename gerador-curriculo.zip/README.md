# Gerador de Currículo

Este é um projeto simples em React + Tailwind para gerar currículos personalizados.